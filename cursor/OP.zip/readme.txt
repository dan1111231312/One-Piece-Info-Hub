﻿=== Luffy East Blue Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/luffy-east-blue-punter

Author's description:

 "Sprites from One Piece: Jump Up All Stars"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.